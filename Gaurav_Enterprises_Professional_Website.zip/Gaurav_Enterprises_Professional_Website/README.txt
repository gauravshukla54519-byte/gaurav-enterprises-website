GAURAV ENTERPRISES — PROFESSIONAL PUBLIC WEBSITE

1. Extract this ZIP.
2. Open index.html in Chrome to preview.
3. In GitHub repository, click "uploading an existing file".
4. Upload index.html (not the ZIP file), then click Commit changes.
5. Open repository Settings > Pages.
6. Under Build and deployment choose "Deploy from a branch", select branch "main" and folder "/ (root)", then Save.
7. Wait a few minutes and use the published URL shown in Settings > Pages.

Important:
- Public marketing website only. Never upload private billing/customer records to a public repository.
- The enquiry form opens WhatsApp and does not store data in a database.
- Confirm product specifications, stock, rates and business details before relying on them.
- This is not a GST billing system.
